﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace HealthCareLibrary
{
    public class Fees
    {
        //Properties
        [Key]
        public int FeeId { get; set; }

        [ForeignKey("Doctor")]
        public int DoctorId { get; set; }

        [Required]
        public float Fee { get; set; }
    }
}
