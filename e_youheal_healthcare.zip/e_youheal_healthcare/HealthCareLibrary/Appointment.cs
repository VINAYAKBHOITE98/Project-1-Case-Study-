﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace HealthCareLibrary.Entities
{
    //Enum for Status 
    public enum Status
    {
        Pending,
        Confirmed
    }
    public class Appointment

    {
        //Variables And Properties
        [Key]
        public int AppointmentId { get; set; }

        [ForeignKey("Patient")]
        public int PatientId { get; set; }
        
        public Specialization Specialization { get; set; }

        [ForeignKey("Doctor")]
        public int DoctorId { get; set; }
        public DateTime AppointmentDate { get; set; }

        [ForeignKey("Fees")]
        public int Fee { get; set; }
        public Status Status { get; set; }

        [ForeignKey("Doctor")]
        public TimeSlot TimeSlot { get; set; }

        [Required]
        [Display(Name = "Date for Appointment")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        
        public DateTime Date { get; set; }


    }
}   
