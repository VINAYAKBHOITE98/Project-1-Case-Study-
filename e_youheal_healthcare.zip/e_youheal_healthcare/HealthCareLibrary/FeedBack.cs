﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace HealthCareLibrary
{
    public class FeedBack
    {
        //Variables And Properties
        [Key]
        public int FeedbackId { get; set; }

        [ForeignKey("Patient")]
        public int PatientId { get; set; }
        public string Message { get; set; }

    }
}
