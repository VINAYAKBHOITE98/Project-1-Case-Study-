﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HealthCareLibrary
{
    //Enum for Gender
    public enum Genders
    {
        Male,
        Female,
        Other
    }

    //Enum For Blood Groups
    public enum BloodGroup
    {
        APositive,
        ANegative,
        BPositive,
        BNegative,
        ABPositive,
        OPositive,
        ONegative,
        ABNegative
    }
    

    //Patient class
    public class Patient
    {
        //Variables, Properties And Validations
        [Key]
        public int PatientId { get; set; }


        [Required]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Name must contains only alphabets")]
        [StringLength(50, ErrorMessage = "Name should have 1-50 characters")]
        public string PatientName { get; set; }


        [Required]
        [RegularExpression("^([a-zA-Z0-9-_.]*)@([a-zA-Z]{1,10}).([a-zA-Z]{2,3})$",ErrorMessage ="Email not in proper format")]
        [StringLength(50, MinimumLength =10, ErrorMessage="Email Should have 10-50 characters")]
        public string Email { get; set; }
        [Required]
        public int Age { get; set; }


        [Required]
        public Genders Gender { get; set; }

        [Required]
        public string Address { get; set; }

   
        [Required]
        [RegularExpression("^[0-9]{10}$", ErrorMessage = "Not valid Mobile Number")]
        public string MobileNumber { get; set; }

        public BloodGroup BloodGroup { get; set; }
        
        public string Symptoms { get; set; }

        [Required(ErrorMessage = "Please enter password")]
        [DataType(DataType.Password)]
        [StringLength(100, ErrorMessage = "Password \"{0}\" must have {2} character", MinimumLength = 8)]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{6,}$", 
            ErrorMessage = "Password must contain: Minimum 8 characters atleast 1 UpperCase Alphabet, 1 LowerCase Alphabet, 1 Number and 1 Special Character")]
        public string Password { get; set; }


        [Display(Name = "Confirm password")]
        [Required(ErrorMessage = "Please enter confirm password")]
        [Compare("Password", ErrorMessage = "Confirm password doesn't match, Type again !")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    

    }
}
