﻿namespace EYouHealHealthcareMvc.Models
{
    public class Update
    {
        public string PatientName { get; set; }
        public string DoctorName { get; set; }
        public string AdminName { get; set; }
        public string  Email { get; set; }
        public int Age { get; set; }
        public string MobileNumber { get; set; }
        public string Address { get; set; }
        public string Password { get; set; }
    }
}
