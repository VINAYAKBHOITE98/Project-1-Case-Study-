﻿using EYouHealHealthcare.Models;
using EYouHealHealthcareMvc.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/adminlogin")]
    public class AdminLoginController : Controller
    {
        RestClient client = new RestClient("http://localhost:15769/api");

        public AdminLoginController()
        {

        }
        [HttpGet]

        public IActionResult AdminLogin()
        {
            return View();
        }
       
        [HttpPost]
        public async Task<IActionResult> AdminLogin(AuthRequest authRequest)
        {
            RestRequest request = new RestRequest("/adminlogin", Method.Post);
            request.AddJsonBody(authRequest);

            var jwtToken = await client.PostAsync<string>(request,CancellationToken.None);
            Response.Cookies.Append("Token", jwtToken);

            Response.Redirect("/admin");

            return View();
        }
    }
}
