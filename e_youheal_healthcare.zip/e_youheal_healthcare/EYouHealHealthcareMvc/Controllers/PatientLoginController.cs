﻿using EYouHealHealthcare.Models;
using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System.Threading;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/patientlogin")]
    public class PatientLoginController : Controller
    {
        RestClient client = new RestClient("http://localhost:15769/api");

        [HttpGet]
        public IActionResult PatientLogin()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> PatientLogin(AuthRequest authRequest)
        {

            RestRequest request = new RestRequest("/patientlogin", Method.Post);
            request.AddJsonBody(authRequest);

            var jwtToken = await client.PostAsync<string>(request, CancellationToken.None);
            Response.Cookies.Append("Token", jwtToken);

            Response.Redirect("/patient");

            return View();
        }
    }
}
