﻿using EYouHealHealthcare.Models;
using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System.Threading;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/doctorlogin")]
    public class DoctorLoginController : Controller
    {
        
        //Take url of web api
            RestClient client = new RestClient("http://localhost:15769/api");

            [HttpGet]
            public IActionResult DoctorLogin()
            {
                return View();
            }
            [HttpPost]
            public async Task<IActionResult> DoctorLogin(AuthRequest authRequest)
            {

                RestRequest request = new RestRequest("/doctorlogin", Method.Post);
                request.AddJsonBody(authRequest);

                var jwtToken = await client.PostAsync<string>(request, CancellationToken.None);
                Response.Cookies.Append("Token", jwtToken);

                Response.Redirect("/doctor");

                return View();
            }
        }
}
