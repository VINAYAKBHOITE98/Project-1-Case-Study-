﻿using Microsoft.AspNetCore.Mvc;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/home")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View("~/Views/Home/Index.cshtml");
        }

        [Route("aboutus")]
        public IActionResult AboutUs()
        {
            return View();
        }

        [Route("contactus")]
        public IActionResult ContactUs()
        {
            return View();
        }

    }
}
