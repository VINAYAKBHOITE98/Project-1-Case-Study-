﻿using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System.Threading;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/patient")]
    public class PatientController : Controller
    {
        RestClient client = new RestClient("http://localhost:15769/api");

        [HttpGet]
        public IActionResult Patient()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Patient(DoctorController doctor)
        {

            RestRequest request = new RestRequest("/patient", Method.Post);
            request.AddJsonBody(doctor);

            var jwtToken = await client.PostAsync<string>(request, CancellationToken.None);
            Response.Cookies.Append("Token", jwtToken);

            return View();
        }
    }
}
