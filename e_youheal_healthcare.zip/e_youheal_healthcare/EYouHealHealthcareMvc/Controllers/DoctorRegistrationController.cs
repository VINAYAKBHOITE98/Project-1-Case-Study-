﻿using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/doctorregister")]
    public class DoctorRegistrationController : Controller
    {
        RestClient client = new RestClient("http://localhost:15769/api");

        [HttpGet]
        public IActionResult DoctorRegistration()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> DoctorRegistration(DoctorRegistrationController registration)
        {
            RestRequest request = new RestRequest("/doctorregister", Method.Post);
            request.AddJsonBody(registration);

            var jwtToken = await client.PostAsync<string>(request);

            Response.Cookies.Append("Token", jwtToken);
            Response.Redirect("/doctorlogin");

            return View();
        }
    }
}
