﻿using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System.Threading;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/doctor")]
    public class DoctorController : Controller
    {
        RestClient client = new RestClient("http://localhost:15769/api");

        [HttpGet]
        public IActionResult Doctor()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Doctor(DoctorController doctor)
        {

            RestRequest request = new RestRequest("/doctor", Method.Post);
            request.AddJsonBody(doctor);

            var jwtToken = await client.PostAsync<string>(request, CancellationToken.None);
            Response.Cookies.Append("Token", jwtToken);

            return View();
        }
    }
}
