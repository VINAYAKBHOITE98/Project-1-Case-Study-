﻿using EYouHealHealthcareMvc.Models;
using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/updateadmin")]
    public class UpdateAdmin : Controller
    {
        RestClient client = new RestClient("http://localhost:15769/api");
        [HttpGet]
        public IActionResult UpdateDoctorDetails()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UpdateDoctorDetails(Update updateAdmin)
        {

            RestRequest request = new RestRequest("/updateadmin", Method.Put);
            request.AddJsonBody(updateAdmin);

            RestResponse response = await client.PostAsync(request, CancellationToken.None);
            if (response.StatusCode == HttpStatusCode.OK)
            {
                ViewBag.IsSuccess = true;
                ViewBag.Message = " Admin Updated Successfully";
            }
            ViewBag.Error = response.ErrorMessage;

            return View("/admin");
        }
    }
}
