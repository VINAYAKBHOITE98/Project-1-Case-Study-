﻿using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/patientregister")]
    public class PatientRegistrationController : Controller
    {
        RestClient client = new RestClient("http://localhost:15769/api");
        [HttpGet]
        public IActionResult PatientRegistration()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> PatientRegistration(PatientRegistrationController registration)
        {
            RestRequest request = new RestRequest("/patientregister", Method.Post);
            request.AddJsonBody(registration);

            var jwtToken = await client.PostAsync<string>(request);
            Response.Cookies.Append("Token", jwtToken);

            Response.Redirect("/patientlogin");

            return View();
        }
    }
}
