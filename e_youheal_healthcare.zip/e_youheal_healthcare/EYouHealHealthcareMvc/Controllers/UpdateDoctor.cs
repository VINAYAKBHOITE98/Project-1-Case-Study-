﻿using EYouHealHealthcareMvc.Models;
using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/updatedoctor")]
    public class UpdateDoctor : Controller
    {
        RestClient client = new RestClient("http://localhost:15769/api");
        [HttpGet]
        public IActionResult UpdateDoctorDetails()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UpdateDoctorDetails(Update updateDoctor)
        {

            RestRequest request = new RestRequest("/updatedoctor", Method.Put);
            request.AddJsonBody(updateDoctor);

            RestResponse response = await client.PostAsync(request, CancellationToken.None);
            if (response.StatusCode == HttpStatusCode.OK)
            {
                ViewBag.IsSuccess = true;
                ViewBag.Message = "Doctor Updated Successfully";
            }
            ViewBag.Error = response.ErrorMessage;

            return View("/doctor");
        }
    }
}
