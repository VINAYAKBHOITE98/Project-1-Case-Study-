﻿using EYouHealHealthcareMvc.Library;
using HealthCareLibrary;
using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{

    [Route("/adminregister")]

    public class AdminRegistrationController : Controller
    {

        RestClient client = new RestClient("http://localhost:15769/api");

        [HttpGet]
        public IActionResult AdminRegistration()
        {
            return View();
        }

        //[HttpPost]
        //public async Task<IActionResult> AdminRegistration(AdminRegistrationController registration)
        //{
        //    RestRequest request = new RestRequest("/adminregister", Method.Post);
        //    request.AddJsonBody(registration);

        //    var jwtToken = await client.PostAsync<string>(request);

        //    Response.Cookies.Append("Token", jwtToken);

        //    Response.Redirect("/adminlogin");

        //    return View();
        //}

        [HttpPost]

        public async Task<IActionResult> AdminRegistration(Admin registration)
        {
            RestRequest request = new RestRequest("/adminregister", Method.Post);
            registration.Role = "Admin";
            registration.Password = EncryptionLibrary.EncryptText(registration.Password);
            registration.ConfirmPassword = EncryptionLibrary.EncryptText(registration.ConfirmPassword);
            request.AddJsonBody(registration);

            RestResponse response = await client.ExecutePostAsync(request, CancellationToken.None);
            if (response.StatusCode == HttpStatusCode.OK)
            {
                ViewBag.IsSuccess = true;
                ViewBag.Message = "Registration Successful!";
                Response.Redirect("/adminlogin");
                //return View("Register");

            }
            ViewBag.Error = response.ErrorMessage;
            return View("AdminRegistration");

        }


    }
}

