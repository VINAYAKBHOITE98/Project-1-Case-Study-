﻿using Microsoft.AspNetCore.Mvc;

namespace EYouHealHealthcareMvc.Controllers
{
    public class ViewPatient : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
