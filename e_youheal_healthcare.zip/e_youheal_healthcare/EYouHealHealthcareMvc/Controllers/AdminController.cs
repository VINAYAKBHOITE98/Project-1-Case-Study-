﻿using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace EYouHealHealthcareMvc.Controllers
{
    [Route("/admin")]
    public class AdminController : Controller
    {
        RestClient client = new RestClient("http://localhost:15769/api");
        [HttpGet]
        public IActionResult Admin()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Admin(AdminController admin)
        {

            RestRequest request = new RestRequest("/admin", Method.Post);
            request.AddJsonBody(admin);

            var jwtToken = await client.PostAsync<string>(request, CancellationToken.None);
            Response.Cookies.Append("Token", jwtToken);

            return View();
        }
      }
    }




