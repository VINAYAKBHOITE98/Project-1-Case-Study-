﻿using HealthCareLibrary;
using HealthCareLibrary.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace EYouHealHealthcare.Controllers
{
   
        [Route("api/doctor")]
        [ApiController]
        [Authorize]
        public class DoctorController : Controller
        {

            HealthCareContext context;

            public DoctorController(HealthCareContext context)
            {
                this.context = context;
            }

            #region View Patient
            //View Patient
            [Route("viewpatient")]
            [Authorize(Roles = "Doctor,Admin")]
            [HttpGet]
            public IActionResult Get(int id)
            {

                return Ok(context.Patients);
            }
            #endregion

            #region View Appointment

            //view Appointment by Doctor
            [Route("viewappointment")]
            [Authorize(Roles = "Admin,Doctor")]
            [HttpGet]
            public IActionResult ViewAppointment()
            {

                return Ok(context.Appointments);
            }
            #endregion

            #region Update Doctor
            [Route("updatedoctor")]
            [Authorize(Roles = "Doctor")]
            [HttpPut]
            public IActionResult UpdateDoctor(Doctor updateRegisteredDoctor)
            {
                var u = context.Doctors.FirstOrDefault(d => d.DoctorId == updateRegisteredDoctor.DoctorId);
                if (u != null)
                {
                    u.DoctorName = updateRegisteredDoctor.DoctorName;
                    u.MobileNumber = updateRegisteredDoctor.MobileNumber;
                    u.Email = updateRegisteredDoctor.Email;
                    u.Password = updateRegisteredDoctor.Password;
                    u.ConfirmPassword = updateRegisteredDoctor.ConfirmPassword;

                    context.Doctors.Update(u);
                    context.SaveChanges();

                    return Ok("Doctor Updated Successfully");
                }
                else
                    return Ok("Doctor not found");
            }
            #endregion

            #region create Prescription
            [HttpPost]
        [Authorize(Roles = "Doctor")]
        public ActionResult SaveRegisterDetails(Prescription prescriptionDetails)
            {
                //We check if the model state is valid or not. We have used DataAnnotation attributes.
                //If any form value fails the DataAnnotation validation the model state becomes invalid.
                if (ModelState.IsValid)
                {
                    //create database context using Entity framework 
                    using (context)
                    {
                        //If the model state is valid i.e. the form values passed the validation then we are storing the User's details in DB.
                        //Registration registration = new Registration();

                        //Save all details in RegitserUser object
                        if (prescriptionDetails != null)
                        {
                            if (!context.Prescriptions.Any(d => d.PrescriptionId == prescriptionDetails.PrescriptionId))
                            {
                                context.Prescriptions.Add(prescriptionDetails);
                            }
                            else
                            {
                                return Ok("Medication already exist");
                            }

                            context.SaveChanges();
                        }

                        //Calling the SaveDetails method which saves the details.
                        //context.Registration.Add(regDetails);

                    }

                    return Ok("Prescription created successfully");
                }
                else
                {

                    //If the validation fails, we are returning the model object with errors to the view, which will display the error messages.
                    return Ok("Prescription cannot be added");
                }

            }
        #endregion
       
    }
}
