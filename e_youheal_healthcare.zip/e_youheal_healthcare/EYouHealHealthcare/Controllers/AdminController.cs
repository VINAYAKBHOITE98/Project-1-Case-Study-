﻿using EYouHealHealthcare.Models;
using HealthCareLibrary;
using HealthCareLibrary.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace EYouHealHealthcare.Controllers
{

    [Route("api/admin")]
    [ApiController]
    [Authorize]
    public class AdminController : Controller
    {
        
            HealthCareContext context;

            public AdminController(HealthCareContext context)
            {
                this.context = context;
            }
        #region View Patient



        [Route("viewpatient")]
        [Authorize(Roles = "Admin,Doctor")]
        [HttpGet]

        public IActionResult ViewPatient()
        {
            return Ok(context.Patients);
        }

        #endregion

        #region View Doctor
        [Route("viewdoctor")]
        [Authorize(Roles = "Admin")]
        [HttpGet]

        public IActionResult ViewDoctor()
        {
            return Ok(context.Doctors);
        }

        #endregion

        #region View Appointment
        [Route("viewappointment")]
        [Authorize(Roles = "Admin,Doctor")]
        [HttpGet]
        public IActionResult ViewAppointment()
        {

            return Ok(context.Appointments);
        }
        #endregion

        #region Update Appointment
        [Route("updateappointment")]
        [Authorize(Roles = "Admin")]
        [HttpPut]
        public IActionResult PutAppointment(Appointment updateAppointment)
        {
            var u = context.Appointments.FirstOrDefault(d => d.AppointmentId == updateAppointment.AppointmentId);
            if (u != null)
            {
                u.AppointmentId   =   updateAppointment.AppointmentId;
                u.PatientId       =   updateAppointment.PatientId;
                u.Specialization  =   updateAppointment.Specialization;
                u.DoctorId        =   updateAppointment.DoctorId;
                u.AppointmentDate =   updateAppointment.AppointmentDate;
                u.Fee             =   updateAppointment.Fee;
                u.Status          =   updateAppointment.Status;

                context.Appointments.Update(u);
                context.SaveChanges();

                return Ok("Appointment Updated Successfully");
            }
            else
                return Ok("Appointment not found");
        }
        #endregion

        #region Update Admin
        [Route("updateadmin")]
        [Authorize(Roles = "Admin")]
        [HttpPut]
        public IActionResult UpdateAdmin(Admin updateAdmin)
        {
            var u = context.Admins.FirstOrDefault(d => d.AdminId == updateAdmin.AdminId);
            if (u != null)
            {
                u.MobileNumber    =   updateAdmin.MobileNumber;
                u.Email           =   updateAdmin.Email;
                u.Password        =   updateAdmin.Password;
                u.ConfirmPassword =   updateAdmin.ConfirmPassword;

                context.Admins.Update(u);
                context.SaveChanges();

                return Ok("Admin Updated Successfully");
            }
            else
                return Ok("Admin not found");
        }
        #endregion

        #region Delete Patient
        [Authorize(Roles = "Admin")]
        [Route("{patientid}")]
        [HttpDelete]
       
        public IActionResult Delete(int patientid)
        {
            var u = context.Patients.FirstOrDefault(d => d.PatientId == patientid);

            if (u != null)
            {
                context.Remove(u);
                context.SaveChanges();
                return Ok(u);
            }
            else
                return NotFound($"No userfound for {patientid}");
        }
        #endregion

        #region Delete Doctor
        [Authorize(Roles = "Admin")]
        [Route("{id}")]
        [HttpDelete]
        public IActionResult DeleteDoctor(int id)
        {
            var u = context.Doctors.FirstOrDefault(d => d.DoctorId == id);

            if (u != null)
            {
                context.Remove(u);
                context.SaveChanges();
                return Ok(u);
            }
            else
                return NotFound($"No userfound for {id}");
        }

        #endregion

    }
}



















/*ADMIN
  * 
  * View Patient               Admin,Doctor
  * View Doctor                Admin,Patient
  * View Appointment           ----
  * Delete Patient             Admin
  * Add Doctor-- Registration  Admin
  * Update Admin               Admin
  * Update Appointment         Admin
  * Delete Doctor              Admin
  * Delete Admin               Admin
  *
  */

/*DOCTOR
 *           
 * 2) Update Doctor-->Put      Doctor     
 * 3) View Patient--> Get      ----             
 * 4) View Appointment-->Get   Admin,Doctor(whole list)         
 * 5) Add Prescription         Doctor
 * 
 */

/*Patient
 * 
 * Add Patient-- Registration
 * Update Patient               Patient
 * Add Appointment              Patient
 * View Doctor                  ----
 * View Appointment             Patient(only his/her)
 * View Prescription            Patient
 * Delete Appointment           Patient,Admin
 * 
 */

