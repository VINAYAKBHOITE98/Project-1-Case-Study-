﻿using EYouHealHealthcare.Models;
using HealthCareLibrary;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace EYouHealHealthcare.Controllers
{
    [Route("api/doctorlogin")]
    [ApiController]
    public class DoctorLoginController : Controller
    {
        HealthCareContext context = new HealthCareContext();

        public DoctorLoginController()
        {

        }

        [HttpPost]

        public IActionResult Post(AuthRequest authRequest)
        {
            var u = context.Doctors.FirstOrDefault(d => d.Email == authRequest.Email && d.Password == authRequest.Password);
            if (u != null)
            {
                var jwtToken = GenerateToken(u.Email,u.Role);
                return Ok(jwtToken);
            }
            else
                return Unauthorized("Login Failed");
        }
        private string GenerateToken(string email, string role)
        {
            string jwtToken = string.Empty;

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("this will be contain really big big some Secret"));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Email, email));
            claims.Add(new Claim(ClaimTypes.Role, "Doctor"));

            var token = new JwtSecurityToken("myapp.com"
                                            , "myapp.com"
                                            , claims
                                            , expires: DateTime.Now.AddDays(7)
                                            , signingCredentials: credentials);


            jwtToken = new JwtSecurityTokenHandler().WriteToken(token);

            return jwtToken;
        }


    }
}

