﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using HealthCareLibrary;
using System.IdentityModel.Tokens.Jwt;
using System;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using EYouHealHealthcare.Models;
using Microsoft.AspNetCore.Authorization;

namespace EYouHealHealthcare.Controllers
{
    [Route("api/adminlogin")]
    [ApiController]
    
    public class AdminLoginController : Controller
    {

        HealthCareContext context = new HealthCareContext();

        public AdminLoginController()
        {

        }

        [HttpPost]

        public IActionResult Post(AuthRequest auth)
        {
            var u = context.Admins.FirstOrDefault(d => d.Email == auth.Email && d.Password == auth.Password);
            if (u != null)
            {
                var jwtToken = GenerateToken(u.Email,u.Role);
                return Ok(jwtToken);
            }
            else
                return Unauthorized("Login Failed");
        }
        private string GenerateToken(string email,string role)
        {
            string jwtToken = string.Empty;

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("this will be contain really big big some Secret"));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Email, email));
            claims.Add(new Claim(ClaimTypes.Role, "Admin"));

            var token = new JwtSecurityToken("myapp.com"
                                            , "myapp.com"
                                            , claims
                                            , expires: DateTime.Now.AddDays(7)
                                            , signingCredentials: credentials);


            jwtToken = new JwtSecurityTokenHandler().WriteToken(token);
            //Response.Cookies.Append("Token",jwtToken);

            return jwtToken;
        }

    }
}

 
