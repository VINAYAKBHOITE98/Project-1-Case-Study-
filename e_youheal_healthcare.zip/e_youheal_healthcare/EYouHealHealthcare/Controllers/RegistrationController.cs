﻿using HealthCareLibrary;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace EYouHealHealthcare.Controllers
{

    [Route("api/register")]
    [ApiController]
    public class RegistrationController : Controller
    {

        HealthCareContext context;

        public RegistrationController(HealthCareContext context)
        {
            this.context = context;
        }

        #region Admin's Registration

        [Route("adminregister")]
        [HttpPost]
        public ActionResult SaveRegisterDetails(Admin adminRegDetails)
        {
            //We check if the model state is valid or not. We have used DataAnnotation attributes.
            //If any form value fails the DataAnnotation validation the model state becomes invalid.
            if (ModelState.IsValid)
            {
                //create database context using Entity framework 
                using (context)
                {
                    //If the model state is valid i.e. the form values passed the validation then we are storing the User's details in DB.
                    //Registration registration = new Registration();

                    //Save all details in RegitserUser object
                    if (adminRegDetails != null)
                    {
                        if (!context.Admins.Any(d => d.Email == adminRegDetails.Email))
                        {
                            context.Admins.Add(adminRegDetails);
                        }
                        else
                        {
                            return Ok("Username already exist");
                        }

                        context.SaveChanges();
                    }




                    //Calling the SaveDetails method which saves the details.
                    //context.Registration.Add(regDetails);

                }

                return Ok("Register successfully");
            }
            else
            {

                //If the validation fails, we are returning the model object with errors to the view, which will display the error messages.
                return Ok("Registeration Failed");
            }

        }
        #endregion

        #region Patient Registration

        [Route("patientregister")]
        [HttpPost]
        public ActionResult SaveRegisterDetails(Patient regDetails)
        {
            //We check if the model state is valid or not. We have used DataAnnotation attributes.
            //If any form value fails the DataAnnotation validation the model state becomes invalid.
            if (ModelState.IsValid)
            {
                //create database context using Entity framework 
                using (context)
                {
                    //If the model state is valid i.e. the form values passed the validation then we are storing the User's details in DB.
                    //Registration registration = new Registration();

                    //Save all details in RegitserUser object
                    if (regDetails != null)
                    {
                        if (!context.Patients.Any(d => d.Email == regDetails.Email))
                        {
                            context.Patients.Add(regDetails);
                        }
                        else
                        {
                            return Ok("Email Id already exist");
                        }

                        context.SaveChanges();
                    }

                    //Calling the SaveDetails method which saves the details.
                    //context.Registration.Add(regDetails);

                }

                return Ok("Register successfully");
            }
            else
            {

                //If the validation fails, we are returning the model object with errors to the view, which will display the error messages.
                return Ok("Registeration Failed");
            }
            
        }
        #endregion

        #region Doctor's Registration
        [Route("doctorregister")]
        [HttpPost]
            public ActionResult SaveRegisterDetails(Doctor regDetails)
            {
                //We check if the model state is valid or not. We have used DataAnnotation attributes.
                //If any form value fails the DataAnnotation validation the model state becomes invalid.
                if (ModelState.IsValid)
                {
                    //create database context using Entity framework 
                    using (context)
                    {
                        //If the model state is valid i.e. the form values passed
                        //the validation then we are storing the User's details in DB.


                        //Save all details in RegitserUser object
                        if (regDetails != null)
                        {
                            if (!context.Doctors.Any(d => d.Email == regDetails.Email))
                            {
                                context.Doctors.Add(regDetails);
                            }
                            else
                            {
                                return Ok("Username already exist");
                            }

                            context.SaveChanges();
                        }

                        //Calling the SaveDetails method which saves the details.
                        //context.Registration.Add(regDetails);

                    }

                    return Ok("Register successfully");
                }
                else
                {

                    //If the validation fails, we are returning the model object with errors to the view, which will display the error messages.
                    return Ok("Registeration Failed");
                }

            }
            #endregion


        }
    }

