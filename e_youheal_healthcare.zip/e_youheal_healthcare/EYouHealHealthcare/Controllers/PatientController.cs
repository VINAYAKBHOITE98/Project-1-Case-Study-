﻿using HealthCareLibrary;
using HealthCareLibrary.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Linq;

namespace EYouHealHealthcare.Controllers
{
    [Route("api/patient")]
    [ApiController]
    [Authorize]
    public class PatientController : Controller
    {

        HealthCareContext context;

        public PatientController(HealthCareContext context)
        {
            this.context = context;
        }

       #region View Prescription
        //view Prescription by Patient
        [Route("viewprescription")]
        [Authorize(Roles = "Patient")]
        [HttpGet]
        public IActionResult ViewPrescription(int id)
        {

            return Ok(context.Prescriptions);
        }
        #endregion

        #region View Appointment
        //view Appointment by Patient
        [Route("viewappointment")]
        [Authorize(Roles = "Admin,Patient")]
        [HttpGet]
        public IActionResult ViewAppointment(int id)
        {

            return Ok(context.Appointments);
        }
        #endregion

        #region Update Patient
        [Route("updatepatient")]
        [Authorize(Roles = "Patient")]
        [HttpPut]
        public IActionResult UpdatePatient(Patient updateRegisteredPatient)
        {
            var u = context.Patients.FirstOrDefault(d => d.PatientId == updateRegisteredPatient.PatientId);
            if (u != null)
            {
                u.PatientName      = updateRegisteredPatient.PatientName;
                u.MobileNumber     = updateRegisteredPatient.MobileNumber;
                u.Email            = updateRegisteredPatient.Email;
                u.Address          = updateRegisteredPatient.Address;
                u.Password         = updateRegisteredPatient.Password;
                u.ConfirmPassword  = updateRegisteredPatient.ConfirmPassword;

                context.Patients.Update(u);
                context.SaveChanges();

                return Ok("Patient Updated Successfully");
            }
            else
                return Ok("Patient not found");
        }
        #endregion

        #region Add Appointment
        [HttpPost]
        [Authorize(Roles = "Patient")]
        public ActionResult SaveRegisterDetails(Appointment addAppointment)
        {
            //We check if the model state is valid or not. We have used DataAnnotation attributes.
            //If any form value fails the DataAnnotation validation the model state becomes invalid.
            if (ModelState.IsValid)
            {
                //create database context using Entity framework 
                using (context)
                {
                    //If the model state is valid i.e. the form values passed the validation then we are storing the User's details in DB.
                    //Registration registration = new Registration();

                    //Save all details in RegitserUser object
                    if (addAppointment != null)
                    {
                        if (!context.Appointments.Any(d => d.AppointmentId == addAppointment.AppointmentId))
                        {
                            context.Appointments.Add(addAppointment);
                        }
                        else
                        {
                            return Ok("Email Id already exist");
                        }

                        context.SaveChanges();
                    }

                    //Calling the SaveDetails method which saves the details.
                    //context.Registration.Add(addAppointment);

                }

                return Ok("Appointment added successfully");
            }
            else
            {

                //If the validation fails, we are returning the model object with errors to the view, which will display the error messages.
                return Ok("Appointment cannot be added");
            }
        }
        #endregion

        #region Cancel Appointment
        [Authorize(Roles = "Patient,Admin")]
        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete(int id)
        {
            var u = context.Appointments.FirstOrDefault(d => d.AppointmentId == id);

            if (u != null)
            {
                context.Remove(u);
                context.SaveChanges();
                return Ok(u);
            }
            else
                return NotFound($"No Appointments found for {id}");
        }
        #endregion

    }


}
