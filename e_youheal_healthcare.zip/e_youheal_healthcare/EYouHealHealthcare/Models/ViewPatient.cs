﻿using HealthCareLibrary;
using System.ComponentModel.DataAnnotations.Schema;

namespace EYouHealHealthcare.Models
{
    
    public class ViewPatient
    {

        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }
        [ForeignKey("Patient")]
        public Genders Gender { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
        [ForeignKey("Patient")]
        public BloodGroup BloodGroup { get; set; }
        public string Symptoms { get; set; }
    }
    
}
